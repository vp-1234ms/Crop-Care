# YANTRA-HACK
Yantra Hackathon Project called Crop Care made by Team Pixels
