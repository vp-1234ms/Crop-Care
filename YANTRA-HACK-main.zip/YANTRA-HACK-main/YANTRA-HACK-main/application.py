from flask import Flask, request, render_template,app
from PIL import Image
import numpy as np
import os
from tensorflow import keras
from tensorflow.keras import layers
import requests
import json

import pickle
from sklearn.preprocessing import LabelEncoder

application = Flask(__name__)
app=application



def convert_to_json(url):
    response = requests.get(url)
    data = response.json()

    json_data = json.dumps(data, indent=4)

    return json_data

def parse_json(json_string):
    parsed_data = json.loads(json_string)
    return parsed_data


@app.route('/crop-prediction')
def home():
    url = 'https://api.thingspeak.com/channels/2179427/feeds.json?api_key=GV3RB48SIMGIGE5H&results=1%20this%20link%20will%20give%20you%20the%20latest%20value'  # Replace with the actual website URL

    json_data = convert_to_json(url)

    # Example usage
    json_string = json_data
    parsed_data = parse_json(json_string)
    field1=round(float(parsed_data['feeds'][0]["field1"]))
    field2=round(float(parsed_data['feeds'][0]["field2"]))
    field3=round(float(parsed_data['feeds'][0]["field3"]))

    print(field2,field3,field1," hi")
    return render_template('crop-prediction.html',fd1=field1,fd2=field2,fd3=field3)



@app.route('/crp',methods=['POST'])
def crp():
    humidity = request.form.get('Humidity')
    temperature = request.form.get('Temperature')
    moisture = request.form.get('Moisture')
    model_path = 'final.pkl'
# Load the model
    with open(model_path, 'rb') as f:
        loaded_model = pickle.load(f)

# Example input data
    input_data = [[humidity,temperature,moisture]]  # Replace with your own input list

# Make predictions using the loaded model
    ot = loaded_model.predict(input_data)

    if(ot[0]==20):
        k='Rice'  
    elif(ot[0]==11):
        k='Maize'
    elif(ot[0]==3):
        k='Chickpea'
    elif(ot[0]==9):
        k='Kidneybeans'
    elif(ot[0]==18):
        k='Pigeonpeas' 
    elif(ot[0]==13):
        k= 'Mothbeans' 
    elif(ot[0]==14):
        k='Mungbean'
    elif(ot[0]==2):
        k='Blackgram'
    elif(ot[0]==10):
        k='Lentil'
    elif(ot[0]==19):
        k='Pomegranate'
    elif(ot[0]==1):
        k='Banana'
    elif(ot[0]==12):
        k='Mango'
    elif(ot[0]==7):
        k='Grapes'
    elif(ot[0]==21):
        k='Watermelon'
    elif(ot[0]==15):
        k='Muskmelon'
    elif(ot[0]==0):
        k= 'Apple'
    elif(ot[0]==16):
        k= 'Orange'
    elif(ot[0]==17):
        k='Papaya'
    elif(ot[0]==4):
        k='Coconut'
    elif(ot[0]==6):
        k='Cotton'
    elif(ot[0]==8):
        k='Jute'
    elif(ot[0]==5):
        k='Coffee'
    return render_template('result2.html',output=k)

@app.route('/home')
def hom():
    return render_template('home.html')

@app.route('/disease-prediction')
def index():
    return render_template('disease-prediction.html')

@app.route('/upload', methods=['POST'])
def upload():
    
    if 'image' not in request.files:
        return 'No image uploaded'
    new_image_path = r"img/image.jpg"
    input_width, input_height = 224, 224

    image = request.files['image']
    
    # Save the image to a specific path
    image.save('static\img\image.jpg')
    st = request.form['crop']
    if(st=="Apple"):
        # Make predictions on a new image using the saved model
        def predict_image(image_path):
            # Set the desired dimensions for the input images
            input_width, input_height = 224, 224
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("AppleFruit")
            prediction = model.predict(img_array)
            class_label = "Apple With Black Rot" if prediction[0][0] < 0.5 else "Healthy Apple"
            return class_label
        # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Potato"):
        # Make predictions on a new image using the saved model
        # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Potato Fruit")
            prediction = model.predict(img_array)
            class_label = "Potato With Early Blight" if prediction[0][0] < 0.5 else "Healthy Potato"
            return class_label
        # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Tomato"):
            # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Tomato Fruit")
            prediction = model.predict(img_array)
            class_label = "Tomato backtorial Spot" if prediction[0][0] < 0.5 else "Healthy Tomato"
            return class_label
        # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Cron"):
        # Make predictions on a new image using the saved model
        # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Potato Fruit")
            prediction = model.predict(img_array)
            class_label = "Corn With Common Rust" if prediction[0][0] < 0.5 else "Healthy Corn"
            return class_label
        # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Bell Pepper"):
    # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Potato Fruit")
            prediction = model.predict(img_array)
            class_label = "Bell Pepper With Bactorial Spot" if prediction[0][0] < 0.5 else "Healthy Bell Pepper"
            return class_label
        # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Strawberry"):
                # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Strawberry Fruit")
            prediction = model.predict(img_array)
            class_label = "Strawberry With Leaf Scorch" if prediction[0][0] < 0.5 else "Healthy Strawberry"
            return class_label
            # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Cherry"):
                # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Cherry Fruit")
            prediction = model.predict(img_array)
            class_label = "Cherry With Powder Mildrew" if prediction[0][0] < 0.5 else "Healthy Cherry"
            return class_label
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Peach"):
                # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Peach Fruit")
            prediction = model.predict(img_array)
            class_label = "Peach With Bacterial Spot" if prediction[0][0] < 0.5 else "Healthy Peach"
            return class_label
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)


    elif(st=="Citrus"):
                # Make predictions on a new image using the saved model
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("Potato Fruit")
            prediction = model.predict(img_array)
            class_label = "Citrus With Black Spot" if prediction[0][0] < 0.5 else "Healthy Citrus"
            return class_label
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)

    elif(st=="Grape"):
        # Make predictions on a new image
        def predict_image(image_path):
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            prediction = model10.predict(img_array)
            model = keras.models.load_model("Potao Fruit")
            class_label = "Grape With Black Measles" if prediction[0][0] < 0.5 else "Healthy Grape"
            return class_label
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)
    elif(st=="Hibiscus"):
        # Make predictions on a new image using the saved model
        def predict_image(image_path):
            # Set the desired dimensions for the input images
            input_width, input_height = 224, 224
            img = Image.open(image_path)
            img = img.resize((input_width, input_height))
            img_array = np.array(img)
            img_array = img_array / 255.0  # Normalize pixel values between 0 and 1
            img_array = np.expand_dims(img_array, axis=0)  # Add an extra dimension for batch
            model = keras.models.load_model("AppleFruit")
            prediction = model.predict(img_array)
            class_label = "Hibiscus With Disease" if prediction[0][0] < 0.5 else "Healthy Hibiscus"
            return class_label
        # Provide the path to a new image for prediction
        new_image_path = r"static\img\image.jpg"
        prediction = predict_image(new_image_path)
        print("Prediction:", prediction)
    
    return render_template('result.html',pred=prediction)


@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    else:
        return


if __name__ == '__main__':
    app.run(host='0.0.0.0')
